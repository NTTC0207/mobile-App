package my.edu.utar.cheehaoyang;

public class User {
    public String fullName , email;

    public User(){

    }

    public User(String fullName,  String email){
        this.fullName =fullName;
//        this.age =age;
        this.email =email;
    }




}
